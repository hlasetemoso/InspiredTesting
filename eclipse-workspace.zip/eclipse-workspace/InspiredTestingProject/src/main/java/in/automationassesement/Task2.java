package in.automationassesement;

public class Task2 {
public String Sample() {
	
	return "sample";
}
}
