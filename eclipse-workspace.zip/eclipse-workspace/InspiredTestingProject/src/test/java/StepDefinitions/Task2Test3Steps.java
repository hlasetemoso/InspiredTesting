package StepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class Task2Test3Steps {

	
	WebDriver driver = null; 
	
	
	@Given("Client is on login page")
	public void client_is_on_login_page() {
		System.out.println("Inside Step - client is on login page");
		
		String projectPath = System.getProperty("user.dir");
		System.out.println("Poject Path is :"+projectPath);
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS); 
	    driver.manage().window().maximize();
	    driver.navigate().to("http://www.way2automation.com/angularjs-protractor/banking/#/login");
	}

	
	@When("Client clicks Login button")
	public void client_clicks_Login_button() {
		System.out.println("Inside Step -client clicks the login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[1]/div[1]/button")).click();
	}

	@When("Client selects username")
	public void client_selects_username() {
		System.out.println("client selects a username");
		driver.findElement(By.id("userSelect")).sendKeys("harry potter");
		
	}
	@Then("Client clicks on login button")
	public void client_clicks_on_login_button() {
		System.out.println("Inside Step - client clicks login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/form/button")).click();
	}
	

	@Then("Client is navigated to the home page")
	public void client_is_navigated_to_the_home_page() {
		System.out.println("Inside Step - client is navigated to home page");
	}

	@Then("Client deposists {int} to first account")
	public void client_deposists_to_first_account(Integer int1) {
		System.out.println("Inside Step - User deposits 31459");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("31459");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();
	}
	
	@Then("Client opens transactions")
	public void client_opens_transactions() {
		System.out.println("Inside Step - client opens transactions");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[1]")).click();
	}

	@Then("Client validates the transaction appears")
	public void client_validates_the_transaction_appears() {
		System.out.println("Inside Step - validates that the transaction appears");
		
		String source = driver.getPageSource();
		if(source.contains("31459"))
		    System.out.println("The transaction appears");
		else
		    System.out.println("The transaction is not appearing");
	}

	@Then("Client Opens Withdrawl")
	public void client_Opens_Withdrawl() {
		System.out.println("Inside Step - Client opens Withdrawal");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[3]")).click();
	}

	@Then("Client Withdraws {int}")
	public void client_Withdraws(Integer int1) {
		System.out.println("Inside Step - client withraws 31459");
		//driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("31459");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();
	}

	@Then("Client Validates the current Balance is the original balance")
	public void client_Validates_the_current_Balance_is_the_original_balance() {
		System.out.println("Inside Step - validate that balance is the initial balance");
		
		String source = driver.getPageSource();
		if(source.contains("62918"))
		    System.out.println("Balance is the same as the original");
		else
		    System.out.println("Balance has changed");

	}

	@Then("Client Opens Transactions")
	public void client_Opens_Transactions() {
		System.out.println("Inside Step - client opens transactions");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[1]")).click();

	}
	
	@Then("Client Validates the Transaction appears")
	public void client_Validates_the_Transaction_appears() {
		System.out.println("Inside Step - validate that transaction appears");
		
		String source = driver.getPageSource();
		if(source.contains("31459"))
		    System.out.println("The transaction appears");
		else
		    System.out.println("The transaction is not here");

	}
	    
	@Then("client logs out")
	public void client_logs_out() {
	System.out.println("Inside Step - User is logs out"); 
	driver.findElement(By.xpath("/html/body/div[3]/div/div[1]/button[2]")).click();
	
	}
}
