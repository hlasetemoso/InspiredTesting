package StepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class test2task2steps {

	
	WebDriver driver = null; 
	
	@Given("Customer is on login page")
	public void Customer_is_on_login_page() {
		System.out.println("Inside Step - User is on login page");
		
		String projectPath = System.getProperty("user.dir");
		System.out.println("Poject Path is :"+projectPath);
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS); 
	    driver.manage().window().maximize();
	    
	    driver.navigate().to("http://www.way2automation.com/angularjs-protractor/banking/#/login");
	}

	@When("Customer clicks Login button")
	public void Customer_clicks_Login_button() {
		System.out.println("Inside Step -User clicks the login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[1]/div[1]/button")).click();
	}


	@And("Customer selects username")
	public void Customer_selects_username() {
		System.out.println("Customer selects a username");
		driver.findElement(By.id("userSelect")).sendKeys("harry potter");
		
	}
	
	@And("Customer clicks on login button")
	public void Customer_clicks_on_login_button() {
		System.out.println("Inside Step - Customer clicks login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/form/button")).click();
	}
	
	
	@And("Customer is navigated to the home page")
	public void Customer_is_navigated_to_the_home_page() {
		System.out.println("Inside Step - Customer is navigated to home page");
	}
		
	@And("Customer deposists {int} to each account")
	public void Customer_deposists(Integer int1)  {
		System.out.println("Inside Step - Customer deposits 1500");
		//deposit for account 1004
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("1500");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();
		
		//System.out.println("Inside Step - validate that the deposit was successfull");
		
		String source = driver.getPageSource();
		if(source.contains("Deposit Successful"))
		    System.out.println("Deposit to Acc-1004 was successful");
		else
		    System.out.println("Deposit was not successful");
		
		//deposit for account 1005
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[1]/select")).sendKeys("1");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("1500");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();
		//System.out.println("Inside Step - validate that the deposit was successfull");
		
		String sourceb = driver.getPageSource();
		if(sourceb.contains("Deposit Successful"))
		    System.out.println("Deposit to Acc-1005 was successful");
		else
		    System.out.println("Deposit was not successful");
		//deposit for account 1006
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[1]/select")).sendKeys("1");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("1500");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();
		//System.out.println("Inside Step - validate that the deposit was successful
		String sourcec = driver.getPageSource();
		if(sourcec.contains("Deposit Successful"))
		    System.out.println("Deposit to Acc-1006 was successful");
		else
		    System.out.println("Deposit was not successful");
	}

	@And("Customer validates that deposit was succesful")
	public void Customer_validates_that_deposit_was_succesful() {
		System.out.println("Inside Step - validate that the deposit was successfull");
		
		String source = driver.getPageSource();
		if(source.contains("Deposit Successful"))
		    System.out.println("Deposit was successful");
		else
		    System.out.println("Deposit was not successful");
	}

	@Then("Customer logs out")
	public void Customer_logs_out() {
	System.out.println("Inside Step - Customer is logged out"); 
	driver.findElement(By.xpath("/html/body/div[3]/div/div[1]/button[2]")).click();
	
	    
	
	}
}
