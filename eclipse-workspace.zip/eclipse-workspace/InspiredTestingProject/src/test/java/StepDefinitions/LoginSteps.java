package StepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class LoginSteps {

	
	WebDriver driver = null; 
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
		System.out.println("Inside Step - User is on login page");
		
		String projectPath = System.getProperty("user.dir");
		System.out.println("Poject Path is :"+projectPath);
		System.setProperty("webdriver.chrome.driver",projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver = new ChromeDriver();
		
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS); 
	    driver.manage().window().maximize();
	    
	    driver.navigate().to("http://www.way2automation.com/angularjs-protractor/banking/#/login");
	}

	@When("user clicks Cusomer Login button")
	public void user_clicks_Cusomer_Login_button() {
		System.out.println("Inside Step -User clicks the login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[1]/div[1]/button")).click();
	}


	@And("user selects username")
	public void user_selects_username() {
		System.out.println("User selects a username");
		driver.findElement(By.id("userSelect")).sendKeys("harry potter");
		
	}
	
	@And("clicks on login button")
	public void clicks_on_login_button() {
		System.out.println("Inside Step - User clicks login button");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/form/button")).click();
	}
	
	
	@And("user is navigated to the home page")
	public void user_is_navigated_to_the_home_page() {
		System.out.println("Inside Step - User is navigated to home page");
	}
		
	@When("user deposists {int}")
	public void user_deposists(Integer int1)  {
		System.out.println("Inside Step - User deposits 1500");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[3]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/div/input")).sendKeys("1500");
		driver.findElement(By.xpath("/html/body/div[3]/div/div[2]/div/div[4]/div/form/button")).click();

		
	}

	@And("User validates that deposit was succesful")
	public void user_validates_that_deposit_was_succesful() {
		System.out.println("Inside Step - validate that the deposit was successfull");
		
		String source = driver.getPageSource();
		if(source.contains("Deposit Successful"))
		    System.out.println("Deposit was successful");
		else
		    System.out.println("Deposit was not successful");

	}

	@Then("user logs out")
	public void user_logs_out() {
	System.out.println("Inside Step - User is logs out"); 
	driver.findElement(By.xpath("/html/body/div[3]/div/div[1]/button[2]")).click();
	
	    
	}
}
