package StepDefinitions;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="Features/Task2Test3.feature", glue={"StepDefinitions"},
monochrome=true,
plugin = {"pretty","junit:target/JUnitReports/Task2Test3Report.xml"}
)

public class Task2Test3Runner {

}