#author : Temoso
#date : 2020-08-14


-These tests were conducted using Cucumber and Java. 
-The Project name = InspiredTestingProject(Maven project with added Dependencies-selenium, junit etc.,)
-The Project has a chromedriver attached to it so you can Simply run the feature files 
-Each feature file is a test from a task
-For Reporting run the the Test Runners for each test task, then navigate to target -JUnitReprots/ JSONReports> 

